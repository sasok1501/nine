<?php
session_start();
$mysqli = new mysqli("localhost", "starov", "84XxRsAd$", "starov");

// Проверка соединения
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Определение типа и направления сортировки
$sortType = isset($_GET['sort']) ? $_GET['sort'] : 'name';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'ASC';

$query = "SELECT * FROM katalog ORDER BY $sortType $sortOrder";
$result = $mysqli->query($query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/index.css">
    <title>Каталог</title>
</head>
<body>
    <header>
    <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
    <nav>
        <a href="index.php">Главная</a>
        <a href="katalog.php">Каталог</a>
        <a href="onas.php">О нас</a>
        <a href="otziv.php">Отзывы</a>
        <a href="shopping_cart.php">Корзина</a>
        <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
    </nav>
    </header>

    <div class='sort-buttons'>
        <form method='GET'>
            <input type='hidden' name='sort' value='name'>
            <input type='hidden' name='order' value='ASC'>
            <button type='submit'>Сортировать по названию (по возрастанию)</button>
        </form>

        <form method='GET'>
            <input type='hidden' name='sort' value='name'>
            <input type='hidden' name='order' value='DESC'>
            <button type='submit'>Сортировать по названию (по убыванию)</button>
        </form>

        <form method='GET'>
            <input type='hidden' name='sort' value='price'>
            <input type='hidden' name='order' value='ASC'>
            <button type='submit'>Сортировать по цене (по возрастанию)</button>
        </form>

        <form method='GET'>
            <input type='hidden' name='sort' value='price'>
            <input type='hidden' name='order' value='DESC'>
            <button type='submit'>Сортировать по цене (по убыванию)</button>
        </form>
    </div>

    <?php
    echo "<div class='text1'>";

    while ($row = $result->fetch_assoc()) {
        echo "<div class='text1'>";
        echo "<p>" . $row["name"] . "</p>";
        echo "<img src='../img/" . $row['img'] . "'class='ikon'>";
        echo "<p>Цена: " . $row["price"] . " </p>";

        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            echo "<form method='POST' action='add_to_card.php'>";
            echo "<input type='hidden' name='product_id' value='" . $row["id"] . "'>";
            echo "<button type='submit' class='buy'>Добавить в корзину</button>";
            echo "</form>";
        } else {
            echo "<p>Авторизуйтесь, чтобы добавить товар в корзину.</p>";
        }

        echo "</div>";
    }

    echo "</div>";
    echo "<br>";
    ?>

<footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>
