<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..\css\index.css">
    <title>О нас</title>
</head>
<body>
    <header>
    <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
    <nav>
        <a href="index.php">Главная</a>
        <a href="katalog.php">Каталог</a>
        <a href="onas.php">О нас</a>
        <a href="otziv.php">Отзывы</a>
        <a href="shopping_cart.php">Корзина</a>
        <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
    </nav>

    <div class="text1">
<h2>Для клиентов</h2>

Наши клиенты – в центре всего, что мы делаем,
Доверие - главное. Мы строим долгосрочные отношения,
Во всём, чем занимаемся, стремимся быть экспертами,
Открыты для предложений и улучшений.
<h2>Для партнёров</h2>
Прозрачность - основа совместного бизнеса,
Работаем, соблюдая этику бизнеса,
Уважаем другие мнения и интересы,
Выполняем обязательства и берем ответственность за свои решения,
Нетерпимы к коррупции.
<h2>Для сотрудников</h2>
Стеклянный мастер - территория личной и коллективной самореализации,
Мы - одна команда,
Уважаем мнение и интересы людей,
Ценим свободу, смелость и ответственность.
</div>
<br>
<footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>