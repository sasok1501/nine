<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    $_SESSION['cart'][] = $product_id;

    // Redirect to the shopping cart page
    header("Location: shopping_cart.php");
    exit();
} else {
    // Redirect to an error page or the main page if the form was not submitted properly
    header("Location: index.php");
    exit();
}
?>
