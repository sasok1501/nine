<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..\css\index.css">
    <title>Контакты</title>
</head>
<body>
    <header>
    <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
    <nav>
        <a href="index.php">Главная</a>
        <a href="katalog.php">Каталог</a>
        <a href="onas.php">О нас</a>
        <a href="otziv.php">Отзывы</a>
        <a href="shopping_cart.php">Корзина</a>
        <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
    </nav>


    <div class="text1">

<?php 
// Connect to the database
$mysqli = new mysqli("localhost", "starov", "84XxRsAd$", "starov");

// Retrieve comments from the database
$query = "SELECT * FROM otziv";
$result = $mysqli->query($query);

echo "<div class='review-block'>";
while ($row = $result->fetch_assoc()) {
    echo "<div class='review'>";
    echo "<h3>" . $row['name'] . "</h3>";
    echo "<p>" . $row['slova'] . "</p>";
    echo "<p>". "Оценка:" . $row['estimation']. "/5" . "</p>";
    echo "</div>";
}
echo "</div>";
?>

</div>
<footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>