<?php
session_start();

$mysqli = new mysqli("localhost", "starov", "84XxRsAd$", "starov");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$errors = array();

if (isset($_POST['reg'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $email = $_POST['email'];
    $fullname = $_POST['fullname'];
    $age = $_POST['age'];
    $city = $_POST['city'];

    // Проверка на пустые поля

if (empty($username)) {
    $errors['username'] = "Заполните поле 'Логин'!";
}
if (empty($_POST['password'])) {
    $errors['password'] = "Заполните поле 'Пароль'!";
}
if (empty($email)) {
    $errors['email'] = "Заполните поле 'Email'!";
}
if (empty($fullname)) {
    $errors['fullname'] = "Заполните поле 'Полное имя'!";
}
if (empty($age)) {
    $errors['age'] = "Заполните поле 'Возраст'!";
}
if (empty($city)) {
    $errors['city'] = "Заполните поле 'Город'!";
}

if (empty($errors)) {
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $stmt = $mysqli->prepare("INSERT INTO users (username, password, email, fullname, age, city) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssis", $username, $password, $email, $fullname, $age, $city);
    $stmt->execute();
    $stmt->close();

    $_SESSION['username'] = $username;
    header('Location: profile.php');
    exit();
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/reg.css">
    <title>Регистрация</title>
    <style>
        .error {
            color: red;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
    <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
    <nav>
        <a href="index.php">Главная</a>
        <a href="katalog.php">Каталог</a>
        <a href="onas.php">О нас</a>
        <a href="otziv.php">Отзывы</a>
        <a href="shopping_cart.php">Корзина</a>
        <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
    </nav>
    </header>

    <form method="POST" action="register.php">
        <h2>Регистрация</h2>
        <label for="username">Логин:</label>
        <input type="text" name="username">
        <?php if (isset($errors['username'])) echo "<span class='error'>{$errors['username']}</span>"; ?>
        <br>

        <label for="password">Пароль:</label>
        <input type="password" name="password">
        <?php if (isset($errors['password'])) echo "<span class='error'>{$errors['password']}</span>"; ?>
        <br>

        <label for="email">Email:</label>
        <input type="email" name="email">
        <?php if (isset($errors['email'])) echo "<span class='error'>{$errors['email']}</span>"; ?>
        <br>

        <label for="fullname">Полное имя:</label>
        <input type="text" name="fullname">
        <?php if (isset($errors['fullname'])) echo "<span class='error'>{$errors['fullname']}</span>"; ?>
        <br>

        <label for="age">Возраст:</label>
        <input type="number" name="age">
        <?php if (isset($errors['age'])) echo "<span class='error'>{$errors['age']}</span>"; ?>
        <br>

        <label for="city">Город:</label>
        <input type="text" name="city">
        <?php if (isset($errors['city'])) echo "<span class='error'>{$errors['city']}</span>"; ?>
        <br>

        <input type="submit" name="reg" value="Зарегистрироваться">
        <a href="login.php">Авторизация</a>
        <br>
        <a href="index.php">На главную</a>
    </form>

    <footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>
