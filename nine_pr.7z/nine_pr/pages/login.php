<?php
session_start();

$mysqli = new mysqli("localhost", "starov", "84XxRsAd$", "starov");

if ($mysqli->connect_error) {
    die('Ошибка подключения: ' . $mysqli->connect_error);
}

$errors = array();

if (isset($_POST['login'])) {
    $loginUsername = $_POST['loginUsername'];
    $loginPassword = $_POST['loginPassword'];

    // Проверка на пустые поля
    if (empty($loginUsername)) {
        $errors['loginUsername'] = "Заполните поле 'Логин'!";
    }
    if (empty($loginPassword)) {
        $errors['loginPassword'] = "Заполните поле 'Пароль'!";
    } else {
        $stmt = $mysqli->prepare("SELECT id, username, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $loginUsername);
        $stmt->execute();
        $stmt->bind_result($userId, $username, $hashedPassword);
        $stmt->fetch();
        $stmt->close();

        if (password_verify($loginPassword, $hashedPassword)) {
            $_SESSION['user_id'] = $userId;
            $_SESSION['username'] = $username;
            header('Location: profile.php');
            exit();
        } else {
            $errors['loginFailed'] = "Неправильный логин или пароль.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/reg.css">
    <title>Авторизация</title>
    <style>
        .error {
            color: red;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
    <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
    <nav>
        <a href="index.php">Главная</a>
        <a href="katalog.php">Каталог</a>
        <a href="onas.php">О нас</a>
        <a href="otziv.php">Отзывы</a>
        <a href="shopping_cart.php">Корзина</a>
        <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
    </nav>
    </header>


    <form method="POST" action="login.php">
        <h2>Авторизация</h2>
        <label for="loginUsername">Логин:</label>
        <input type="text" name="loginUsername"><br>

        <label for="loginPassword">Пароль:</label>
        <input type="password" name="loginPassword"><br>

        <input type="submit" name="login" value="Войти">
        <a href="register.php">Регистрация</a>
        <br>
        <a href="index.php">На главную</a>
        <?php
    // Вывод ошибок, если они есть
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p class='error'>$error</p>";
        }
    }
    ?>
    </form>

    <footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>
