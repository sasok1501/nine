<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..\css\index.css">
    <title>Личный кабинет</title>
</head>
<body>
    <header>
    <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
    </header>
    <nav>
        <a href="index.php">Главная</a>
        <a href="katalog.php">Каталог</a>
        <a href="onas.php">О нас</a>
        <a href="otziv.php">Отзывы</a>
        <a href="shopping_cart.php">Корзина</a>
        <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
    </nav>
    <?php
session_start();

$mysqli = new mysqli("localhost", "starov", "84XxRsAd$", "starov");

// Проверка соединения
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Проверка авторизации пользователя
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Запрос информации о пользователе
    $userQuery = "SELECT * FROM users WHERE id = $userId";
    $userResult = $mysqli->query($userQuery);
    $userRow = $userResult->fetch_assoc();

    // Запрос списка купленных товаров пользователя с кодом и статусом
    $purchasesQuery = "SELECT k.name, k.price, p.product_code, p.status 
                      FROM purchases p
                      JOIN katalog k ON p.product_id = k.id
                      WHERE p.user_id = $userId";
    $purchasesResult = $mysqli->query($purchasesQuery);

    echo "<h2>Личный кабинет</h2>";
    echo "<p>Привет, " . $userRow['username'] . "!</p>";

    // Отображение информации о пользователе
    echo "<h3>Информация о пользователе:</h3>";
    echo "<p>Имя: " . $userRow['fullname'] . "</p>";
    echo "<p>Возраст: " . $userRow['age'] . "</p>";
    echo "<p>Город: " . $userRow['city'] . "</p>";

    // Отображение списка купленных товаров
    echo "<h3>Ваши покупки:</h3>";
    if ($purchasesResult->num_rows > 0) {
        while ($purchaseRow = $purchasesResult->fetch_assoc()) {
            echo "<p>Товар: " . $purchaseRow['name'] . " - Цена: " . $purchaseRow['price'] . " - Код: " . $purchaseRow['product_code'] . " - Статус: " . $purchaseRow['status'] . "</p>";
        }
    } else {
        echo "<p>У вас пока нет покупок.</p>";
    }

    echo "<a href='logout.php'>Выйти</a>";
} else {
    // Если пользователь не авторизован, перенаправляем на страницу авторизации
    header('Location: login.php');
    exit();
}
?>

<footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>