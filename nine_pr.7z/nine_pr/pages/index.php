<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..\css\index.css">
    <title>Главная</title>
</head>
<body>
    <header>
        <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
    </header>
    <nav>
        <a href="index.php">Главная</a>
        <a href="katalog.php">Каталог</a>
        <a href="onas.php">О нас</a>
        <a href="otziv.php">Отзывы</a>
        <a href="shopping_cart.php">Корзина</a>
        <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
    </nav>
    <br>
    <div class="text1">
        <h1>Добро пожаловать, в магазин Магазин часов!</h1>
        <h3>Магазин часов – один из лидеров рынка по продаже
 стеклянных товаров в России. </h3>

 Наша цель изменить жизнь людей,
  сделав простым доступ к огромному количеству
   качественных и недорогих товаров,
  предоставляя лучший сервис.

</div>

<br>
    <footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>