<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/index.css">
    <title>Корзина</title>
</head>
<body>
    <header>
    <a href="index.php"><img src="..\img\logo.jpg" alt="" class="logo"></a>
        <nav>
            <a href="index.php">Главная</a>
            <a href="katalog.php">Каталог</a>
            <a href="onas.php">О нас</a>
            <a href="otziv.php">Отзывы</a>
            <a href="shopping_cart.php">Корзина</a>
            <?php
        // Проверяем, авторизован ли пользователь
        if (isset($_SESSION['user_id'])) {
            // Если пользователь авторизован, показываем ссылку на личный кабинет и "Выйти"
            echo '<a href="profile.php">Личный кабинет</a>';
            echo '<a href="logout.php">Выйти</a>';
        } else {
            // Если пользователь не авторизован, показываем ссылку на регистрацию и "Войти"
            echo '<a href="register.php">Регистрация</a>';
            echo '<a href="login.php">Войти</a>';
        }
        ?>
        </nav>
    </header>

<?php
session_start();

$mysqli = new mysqli("localhost", "starov", "84XxRsAd$", "starov");

// Проверка соединения
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Проверка авторизации пользователя
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Отображение товаров в корзине
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        $cartItems = $_SESSION['cart'];
        echo "<h2>Корзина покупок</h2>";

        $total = 0; // Инициализация общей суммы

        // Итерация по товарам в корзине
        foreach ($cartItems as $product_id) {
            $query = "SELECT * FROM katalog WHERE id = $product_id";
            $result = $mysqli->query($query);
            $row = $result->fetch_assoc();

            // Генерация уникального кода для товара (8 рандомных цифр)
            $productCode = generateRandomCode(8);

            // Отображение товара в корзине
            echo "<div class='text1'>";
            echo "<p>" . $row["name"] . "</p>";
            echo "<img src='../img/" . $row['img'] . "' class='ikon'>";
            echo "<p>Цена: " . $row["price"] . " <a href='remove_from_cart.php?product_id=" . $row['id'] . "'>Удалить</a></p>";
            echo "<p>Код товара: " . $productCode . "</p>";
            echo "</div>";

            // Сохранение информации о покупке в базу данных
            $insertQuery = "INSERT INTO purchases (user_id, product_id, quantity, status, product_code, timestamp)
                            VALUES ('$userId', '$product_id', '1', 'В обработке', '$productCode', NOW())";
            $mysqli->query($insertQuery);

            $total = $row["price"];
        }

        // Отображение общей суммы
        echo "<p><strong>Общая сумма: " . $total . "</strong></p>";

        // Форма для завершения покупки
        echo "<form method='POST' action='profile.php'>";
        echo "<button type='submit' name='complete_purchase'>Завершить покупку</button>";
        echo "</form>";

    } else {
        echo "<p>Ваша корзина для покупок пуста.</p>";
    }

} else {
    // Если пользователь не авторизован, перенаправляем на страницу авторизации
    header('Location: login.php');
    exit();
}

// Функция для генерации уникального кода из N цифр
function generateRandomCode($length) {
    $characters = '0123456789';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}
?>




<footer>
    <p>&copy; 2024 Магазин часов. Все права защищены.</p>
    </footer>
</body>
</html>
